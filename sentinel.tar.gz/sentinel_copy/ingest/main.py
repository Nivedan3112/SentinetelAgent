"""
Sentinel Ingest Service
FastAPI app that:
 - Receives alert webhooks from Prometheus/PagerDuty/Datadog/CloudWatch
 - Normalises payloads to a common schema
 - Runs the Sentinel agent in a background thread
 - Exposes REST endpoints for the web UI
"""
import os
import json
import logging
import threading
from datetime import datetime
from typing import Optional

from fastapi import FastAPI, HTTPException, BackgroundTasks
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse, JSONResponse
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

from agent.tools.notify import get_notifications

# Auto-detect demo mode: use if no API key set or SENTINEL_DEMO_MODE=1
_demo_mode = os.getenv("SENTINEL_DEMO_MODE", "0") == "1" or not os.getenv("ANTHROPIC_API_KEY")

if _demo_mode:
    from agent.demo_orchestrator import run_demo_agent as run_agent
    print("⚡ Sentinel running in DEMO MODE (no API key required)")
else:
    from agent.orchestrator import run_agent
    print("🔑 Sentinel running with Claude API")

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s — %(message)s")
logger = logging.getLogger("sentinel.ingest")

app = FastAPI(title="Sentinel SRE Agent", version="2.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

# In-memory incident store (use Postgres in production)
incidents: dict = {}
_lock = threading.Lock()


# ──────────────────────────────────────────────
# Pydantic models
# ──────────────────────────────────────────────

class PrometheusAlert(BaseModel):
    """Standard Prometheus Alertmanager webhook payload"""
    receiver: str = "sentinel"
    status: str = "firing"
    alerts: list = []

class GenericAlert(BaseModel):
    """Simplified alert for testing"""
    alert_name: str
    service: str
    environment: str = "prod"
    severity: Optional[str] = None
    labels: dict = {}
    annotations: dict = {}


# ──────────────────────────────────────────────
# Normalisation helpers
# ──────────────────────────────────────────────

def normalise_prometheus(payload: dict) -> dict:
    """Convert Prometheus Alertmanager payload to Sentinel schema."""
    alert = payload.get("alerts", [{}])[0]
    labels = alert.get("labels", {})
    return {
        "alert_name":  labels.get("alertname", "UnknownAlert"),
        "service":     labels.get("job", labels.get("app", "unknown-service")),
        "environment": labels.get("env", labels.get("environment", "prod")),
        "severity":    labels.get("severity", None),
        "labels":      labels,
        "annotations": alert.get("annotations", {}),
        "source":      "prometheus",
        "raw":         payload,
    }

def normalise_pagerduty(payload: dict) -> dict:
    event = payload.get("event", {})
    return {
        "alert_name":  event.get("title", "PagerDuty Alert"),
        "service":     event.get("client", "unknown-service"),
        "environment": "prod",
        "labels":      payload,
        "source":      "pagerduty",
        "raw":         payload,
    }

def normalise_generic(payload: dict) -> dict:
    return {
        "alert_name":  payload.get("alert_name", "GenericAlert"),
        "service":     payload.get("service", "unknown-service"),
        "environment": payload.get("environment", "prod"),
        "labels":      payload.get("labels", {}),
        "source":      "generic",
        "raw":         payload,
    }


def run_agent_background(alert: dict, incident_id: str):
    """Run the agent in a background thread and store results."""
    try:
        with _lock:
            incidents[incident_id] = {
                "id": incident_id,
                "status": "investigating",
                "alert": alert,
                "started_at": datetime.utcnow().isoformat(),
                "result": None,
            }

        result = run_agent(alert)

        with _lock:
            incidents[incident_id].update({
                "status": "completed",
                "finished_at": datetime.utcnow().isoformat(),
                "result": result,
            })
        logger.info(f"[{incident_id}] Agent completed successfully")

    except Exception as e:
        logger.error(f"[{incident_id}] Agent failed: {e}", exc_info=True)
        with _lock:
            incidents[incident_id].update({
                "status": "error",
                "error": str(e),
                "finished_at": datetime.utcnow().isoformat(),
            })


# ──────────────────────────────────────────────
# Webhook endpoints
# ──────────────────────────────────────────────

@app.post("/webhook/prometheus", summary="Receive Prometheus Alertmanager webhooks")
async def webhook_prometheus(payload: dict, background_tasks: BackgroundTasks):
    alert = normalise_prometheus(payload)
    incident_id = f"INC-{int(datetime.utcnow().timestamp())}"
    background_tasks.add_task(run_agent_background, alert, incident_id)
    logger.info(f"Prometheus alert received → {incident_id}")
    return {"incident_id": incident_id, "status": "accepted"}


@app.post("/webhook/pagerduty", summary="Receive PagerDuty webhooks")
async def webhook_pagerduty(payload: dict, background_tasks: BackgroundTasks):
    alert = normalise_pagerduty(payload)
    incident_id = f"INC-{int(datetime.utcnow().timestamp())}"
    background_tasks.add_task(run_agent_background, alert, incident_id)
    return {"incident_id": incident_id, "status": "accepted"}


@app.post("/webhook/generic", summary="Generic alert webhook for testing")
async def webhook_generic(alert: GenericAlert, background_tasks: BackgroundTasks):
    payload = normalise_generic(alert.dict())
    incident_id = f"INC-{int(datetime.utcnow().timestamp())}"
    background_tasks.add_task(run_agent_background, payload, incident_id)
    logger.info(f"Generic alert received: {alert.alert_name} on {alert.service} → {incident_id}")
    return {"incident_id": incident_id, "status": "accepted", "message": "Agent is investigating..."}


# ──────────────────────────────────────────────
# REST API for UI
# ──────────────────────────────────────────────

@app.get("/api/incidents", summary="List all incidents")
async def list_incidents():
    with _lock:
        return list(reversed(list(incidents.values())))


@app.get("/api/incidents/{incident_id}", summary="Get incident details")
async def get_incident(incident_id: str):
    with _lock:
        inc = incidents.get(incident_id)
    if not inc:
        raise HTTPException(status_code=404, detail="Incident not found")
    return inc


@app.get("/api/notifications", summary="Get Slack notifications sent by agent")
async def list_notifications():
    return get_notifications()


@app.get("/api/health")
async def health():
    return {"status": "ok", "version": "2.0.0", "incidents_tracked": len(incidents)}


# ──────────────────────────────────────────────
# Demo: pre-baked test alerts
# ──────────────────────────────────────────────

DEMO_ALERTS = [
    {
        "alert_name": "OOMKillDetected",
        "service": "api-gateway",
        "environment": "prod",
        "labels": {"cluster": "us-east-1", "namespace": "production"},
    },
    {
        "alert_name": "HighLatencyP99",
        "service": "payment-service",
        "environment": "prod",
        "labels": {"cluster": "us-east-1"},
    },
    {
        "alert_name": "PodCrashLoopBackOff",
        "service": "auth-service",
        "environment": "prod",
        "labels": {"cluster": "eu-west-1"},
    },
    {
        "alert_name": "DatabaseConnectionExhausted",
        "service": "data-pipeline",
        "environment": "prod",
        "labels": {"cluster": "us-east-1"},
    },
]

@app.post("/api/demo/fire", summary="Fire a random demo alert")
async def fire_demo_alert(background_tasks: BackgroundTasks, index: int = 0):
    """Fire one of the pre-baked demo alerts to trigger the agent."""
    alert = DEMO_ALERTS[index % len(DEMO_ALERTS)]
    payload = normalise_generic(alert)
    incident_id = f"INC-{int(datetime.utcnow().timestamp())}"
    background_tasks.add_task(run_agent_background, payload, incident_id)
    return {
        "incident_id": incident_id,
        "alert_fired": alert["alert_name"],
        "service": alert["service"],
        "status": "investigating",
        "message": "Sentinel is now investigating this incident...",
    }


# ──────────────────────────────────────────────
# Serve static web UI
# ──────────────────────────────────────────────

if os.path.exists("static"):
    app.mount("/static", StaticFiles(directory="static"), name="static")

    @app.get("/", include_in_schema=False)
    async def serve_ui():
        return FileResponse("static/index.html")
