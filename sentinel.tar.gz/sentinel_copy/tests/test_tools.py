"""Unit tests for Sentinel tools (no API key required)."""
import pytest
import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from agent.tools.triage import triage_alert
from agent.tools.check_metrics import check_metrics
from agent.tools.query_logs import query_logs
from agent.tools.run_runbook import run_runbook
from agent.tools.draft_postmortem import draft_postmortem
from agent.tools.notify import notify_slack, get_notifications


def test_triage_p1_oom():
    r = triage_alert("OOMKillDetected", "api-gateway", "prod")
    assert r["severity"] == "P1"
    assert r["failure_category"] == "oom-kill"
    assert r["needs_postmortem"] is True

def test_triage_downgrade_nonprod():
    r = triage_alert("ServiceDown", "api-gateway", "staging")
    assert r["severity"] == "P3"   # P1 downgraded for non-prod

def test_triage_p2_latency():
    r = triage_alert("HighLatencyP99", "payment-service", "prod")
    assert r["severity"] == "P2"
    assert "latency" in r["failure_category"]

def test_check_metrics_returns_all_metrics():
    r = check_metrics("api-gateway", window_minutes=10)
    assert "metrics" in r
    for m in ["cpu_percent", "memory_mb", "error_rate"]:
        assert m in r["metrics"]
        assert "current" in r["metrics"][m]
        assert "timeseries" in r["metrics"][m]

def test_check_metrics_summary():
    r = check_metrics("api-gateway")
    assert "summary" in r
    assert r["summary"]["health_status"] in ("healthy", "degraded")

def test_query_logs_returns_lines():
    r = query_logs("payment-service", level="ERROR", window_minutes=15)
    assert "log_lines" in r
    assert len(r["log_lines"]) > 0
    assert "error_pattern_detected" in r
    assert "total_errors_found" in r

def test_run_runbook_high_memory():
    r = run_runbook("high-memory", "api-gateway")
    assert "findings" in r
    assert "steps_executed" in r
    assert len(r["steps_executed"]) > 0
    assert "recommended_actions" in r

def test_run_runbook_unknown():
    r = run_runbook("does-not-exist", "my-service")
    assert "error" in r
    assert "available_runbooks" in r

def test_run_runbook_marks_destructive_actions():
    r = run_runbook("high-memory", "api-gateway")
    destructive = [a for a in r["recommended_actions"] if a.get("requires_approval")]
    assert len(destructive) > 0, "Destructive actions should require approval"

def test_draft_postmortem_structure():
    r = draft_postmortem("INC-001", "api-gateway", "P1", "oom-kill")
    assert "markdown_content" in r
    assert "INC-001" in r["markdown_content"]
    assert "Action Items" in r["markdown_content"]
    assert r["requires_human_completion"] is True

def test_notify_slack_stores_notification():
    before = len(get_notifications())
    notify_slack(
        severity="P2",
        service="payment-service",
        title="High latency detected",
        root_cause="Connection pool exhausted",
        actions=["Increase pool size", "Restart service"],
        evidence=["P99 latency: 4.8s", "Pool 100% saturated"],
        blast_radius="~5000 users",
        eta_resolution="30 minutes",
    )
    after = len(get_notifications())
    assert after == before + 1
    latest = get_notifications()[0]
    assert latest["severity"] == "P2"
    assert latest["service"] == "payment-service"
