# 🛡️ Sentinel — AI SRE Agent

> An autonomous on-call assistant powered by Claude (claude-sonnet-4-20250514). Sentinel triages alerts, runs diagnostic runbooks, queries metrics and logs, and posts structured incident reports to Slack — all without waking you up for the boring parts.

[![CI](https://github.com/yourorg/sentinel/actions/workflows/ci.yml/badge.svg)](https://github.com/yourorg/sentinel/actions)
[![Python 3.12](https://img.shields.io/badge/python-3.12-blue.svg)](https://python.org)
[![License MIT](https://img.shields.io/badge/license-MIT-green.svg)](LICENSE)

---

## What it does

When an alert fires, Sentinel runs a full agentic investigation loop:

```
Alert received
    │
    ▼
triage_alert       → Severity (P1–P4), service owner, failure category
    │
    ▼
check_metrics      → CPU, memory, error rate, latency P99 (last 30 min)
    │
    ▼
query_logs         → Error patterns, stack traces, frequency analysis
    │
    ▼
run_runbook        → Diagnostic steps for known failure types
    │
    ▼
draft_postmortem   → P1/P2 only — creates Confluence skeleton
    │
    ▼
notify_slack       → Structured report to #incidents
```

**Human-in-the-loop by design**: Sentinel flags every action that touches production as `requires_approval`. It investigates and recommends — humans decide and execute.

---

## Quick start

### Option A: Demo mode (no API key needed)

```bash
git clone https://github.com/yourorg/sentinel
cd sentinel
pip install -r requirements.txt
uvicorn ingest.main:app --reload
# Open http://localhost:8000 → click "Fire alert & run agent"
```

Demo mode runs the full 6-tool pipeline with synthetic data. Perfect for showcasing the system.

### Option B: Real Claude API

```bash
export ANTHROPIC_API_KEY=sk-ant-...
uvicorn ingest.main:app --reload
```

### Option C: Docker Compose

```bash
cp .env.example .env          # add your ANTHROPIC_API_KEY
docker compose up
```

---

## Architecture

```
┌─────────────────────────────────────────────────────────┐
│  Signal Sources                                         │
│  Prometheus  PagerDuty  Datadog  CloudWatch  + more     │
└─────────────────┬───────────────────────────────────────┘
                  │ webhook
                  ▼
┌─────────────────────────────────┐
│  FastAPI ingest service         │
│  Normalise → Redis queue        │
└─────────────────┬───────────────┘
                  │
                  ▼
┌─────────────────────────────────────────────────────────┐
│  Sentinel Agent (Claude claude-sonnet-4-20250514)               │
│                                                         │
│  ┌───────────────┐  ┌────────────┐  ┌────────────────┐ │
│  │ triage_alert  │  │check_metrics│  │  query_logs    │ │
│  └───────────────┘  └────────────┘  └────────────────┘ │
│  ┌───────────────┐  ┌────────────┐  ┌────────────────┐ │
│  │ run_runbook   │  │draft_post  │  │  notify_slack  │ │
│  └───────────────┘  └────────────┘  └────────────────┘ │
└─────────────────────────────────────────────────────────┘
                  │
                  ▼
┌─────────────────────────────────────────────────────────┐
│  Outputs                                                │
│  Slack thread  PagerDuty annotation  Confluence doc     │
└─────────────────────────────────────────────────────────┘
```

---

## Project structure

```
sentinel/
├── agent/
│   ├── orchestrator.py        # Real Claude agentic loop
│   ├── demo_orchestrator.py   # Demo mode (no API key)
│   ├── prompts.py             # System prompt
│   └── tools/
│       ├── triage.py          # Alert classification
│       ├── check_metrics.py   # Prometheus queries
│       ├── query_logs.py      # Loki/CloudWatch log search
│       ├── run_runbook.py     # Diagnostic runbooks (5 types)
│       ├── draft_postmortem.py # Confluence postmortem
│       └── notify.py          # Slack notifications
├── ingest/
│   └── main.py                # FastAPI webhook receiver + REST API
├── static/
│   └── index.html             # POC web dashboard
├── tests/
│   └── test_tools.py          # Unit tests (no API key needed)
├── .github/workflows/ci.yml   # GitHub Actions
├── docker-compose.yml
├── Dockerfile
└── requirements.txt
```

---

## Webhook integration

### Prometheus Alertmanager

```yaml
# alertmanager.yml
receivers:
  - name: sentinel
    webhook_configs:
      - url: http://sentinel:8000/webhook/prometheus
```

### PagerDuty

Add `http://your-sentinel-host/webhook/pagerduty` as a webhook in your PagerDuty service.

### Generic (curl)

```bash
curl -X POST http://localhost:8000/webhook/generic \
  -H "Content-Type: application/json" \
  -d '{
    "alert_name": "HighLatencyP99",
    "service": "payment-service",
    "environment": "prod",
    "labels": {"cluster": "us-east-1"}
  }'
```

---

## Available runbooks

| Runbook | Diagnoses |
|---------|-----------|
| `high-memory` | OOMKill, heap exhaustion, memory leaks |
| `high-latency` | Connection pool saturation, circuit breakers |
| `disk-full` | Log bloat, heap dumps, volume sizing |
| `pod-crashloop` | CrashLoopBackOff, bad deployments, startup failures |
| `db-connection-exhaustion` | PG max_connections, long-running queries, locks |

---

## Adding a new runbook

1. Add an entry to `RUNBOOKS` dict in `agent/tools/run_runbook.py`
2. Each entry needs: `description`, `steps[]`, `findings`, `recommended_actions[]`
3. Mark any destructive action with `{"action": "...", "requires_approval": True}`
4. Add the runbook name to the pattern matcher in `agent/tools/triage.py`

---

## REST API

| Method | Path | Description |
|--------|------|-------------|
| `POST` | `/webhook/prometheus` | Prometheus Alertmanager webhook |
| `POST` | `/webhook/pagerduty` | PagerDuty webhook |
| `POST` | `/webhook/generic` | Generic alert (testing) |
| `POST` | `/api/demo/fire?index=0` | Fire a pre-baked demo alert |
| `GET`  | `/api/incidents` | List all incidents |
| `GET`  | `/api/incidents/{id}` | Incident detail + tool call trace |
| `GET`  | `/api/notifications` | Slack notifications log |
| `GET`  | `/api/health` | Health check |
| `GET`  | `/docs` | Swagger UI |

---

## Configuration

```bash
# .env
ANTHROPIC_API_KEY=sk-ant-...     # Required for real mode
SENTINEL_DEMO_MODE=0              # Set to 1 to force demo mode
SLACK_WEBHOOK_URL=https://hooks.slack.com/...  # Optional
CONFLUENCE_URL=https://yourco.atlassian.net    # Optional
```

---

## Running tests

```bash
# No API key required
pytest tests/ -v

# With coverage
pytest tests/ --cov=agent --cov-report=term-missing
```

---

## Roadmap

- [ ] Real Prometheus HTTP API integration
- [ ] Real Loki LogQL integration  
- [ ] Slack SDK integration (replace simulation)
- [ ] Confluence API for postmortem publishing
- [ ] Persistent storage (Postgres incident history)
- [ ] Multi-agent: escalation agent + remediation agent
- [ ] Memory of past incidents (similar incident lookup)
- [ ] Auto-PR for config fixes (Kubernetes manifests)
- [ ] Helm chart for production deployment

---

## Contributing

PRs welcome. Please add tests for any new tool or runbook.

---

## License

MIT — see [LICENSE](LICENSE)

---

*Built with [Anthropic Claude](https://anthropic.com) · claude-sonnet-4-20250514 · Tool use API*
