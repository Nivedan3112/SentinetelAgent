"""
query_logs tool
Searches Loki/CloudWatch/Elasticsearch for log patterns.
Production: hits Loki HTTP API with LogQL queries.
POC: returns realistic synthetic log entries with injected errors.
"""
import random
from datetime import datetime, timedelta

QUERY_LOGS_TOOL_DEF = {
    "name": "query_logs",
    "description": (
        "Search application logs for a service. Returns recent error log lines, "
        "stack traces, and a frequency breakdown. Use to find root cause evidence."
    ),
    "input_schema": {
        "type": "object",
        "properties": {
            "service": {
                "type": "string",
                "description": "Service name to search logs for"
            },
            "level": {
                "type": "string",
                "enum": ["ERROR", "WARN", "INFO", "DEBUG"],
                "description": "Minimum log level to return (default ERROR)",
                "default": "ERROR",
            },
            "window_minutes": {
                "type": "integer",
                "description": "How far back to search (default 15)",
                "default": 15,
            },
            "search_term": {
                "type": "string",
                "description": "Optional keyword to filter logs, e.g. 'OOM' or 'timeout'",
            },
        },
        "required": ["service"],
    },
}

ERROR_TEMPLATES = [
    {
        "pattern": "OutOfMemoryError",
        "lines": [
            "java.lang.OutOfMemoryError: Java heap space",
            "    at java.util.Arrays.copyOf(Arrays.java:3210)",
            "    at com.sentinel.{service}.cache.LocalCache.put(LocalCache.java:142)",
            "    at com.sentinel.{service}.handler.RequestHandler.process(RequestHandler.java:87)",
            "GC overhead limit exceeded — heap usage: 98.2%",
        ],
        "count": random.randint(12, 40),
    },
    {
        "pattern": "ConnectionTimeout",
        "lines": [
            "ERROR c.s.{service}.db.ConnectionPool - Failed to acquire connection after 5000ms",
            "com.zaxxer.hikari.pool.HikariPool$PoolInitializationException: Failed to initialize pool",
            "Caused by: org.postgresql.util.PSQLException: Connection refused: localhost:5432",
            "Active connections: 100/100 — pool exhausted",
        ],
        "count": random.randint(30, 80),
    },
    {
        "pattern": "PodCrashLoop",
        "lines": [
            "FATAL: Process received signal SIGSEGV",
            "Container exited with code 137 (OOMKilled)",
            "Liveness probe failed: HTTP probe failed with statuscode: 500",
            "Readiness probe failed for container: timeout after 30s",
        ],
        "count": random.randint(5, 15),
    },
    {
        "pattern": "HighLatency",
        "lines": [
            "WARN  c.s.{service}.client.HttpClient - Request to downstream exceeded SLA: 4823ms (threshold: 500ms)",
            "WARN  c.s.{service}.circuit.Breaker - Circuit breaker OPEN for: payment-service",
            "ERROR c.s.{service}.handler.TimeoutHandler - Request timed out after 5000ms",
            "Downstream P99 latency: 4821ms (baseline: 85ms)",
        ],
        "count": random.randint(200, 600),
    },
]

def query_logs(
    service: str,
    level: str = "ERROR",
    window_minutes: int = 15,
    search_term: str = None,
) -> dict:
    now = datetime.utcnow()

    # Pick a realistic error pattern
    template = random.choice(ERROR_TEMPLATES)
    pattern = template["pattern"]

    # Generate timestamped log lines
    logs = []
    for i, line in enumerate(template["lines"]):
        ts = now - timedelta(minutes=random.randint(1, window_minutes))
        formatted_line = line.format(service=service.replace("-", ""))
        logs.append({
            "timestamp": ts.isoformat(),
            "level": "ERROR" if i == 0 or "ERROR" in line else "WARN",
            "service": service,
            "message": formatted_line,
        })

    # Sort by time
    logs.sort(key=lambda x: x["timestamp"])

    # Generate error frequency per minute
    freq = []
    for m in range(window_minutes):
        ts = now - timedelta(minutes=window_minutes - m)
        count = 0 if m < window_minutes - 8 else random.randint(5, 35)
        freq.append({"minute": ts.strftime("%H:%M"), "error_count": count})

    return {
        "service": service,
        "log_source": "loki:3100 (simulated)",
        "query_window_minutes": window_minutes,
        "level_filter": level,
        "search_term": search_term,
        "total_errors_found": template["count"],
        "error_pattern_detected": pattern,
        "log_lines": logs,
        "error_frequency_per_minute": freq,
        "top_error_messages": [
            {"message": template["lines"][0].format(service=service), "count": template["count"]},
            {"message": "Connection refused", "count": template["count"] // 3},
        ],
        "first_occurrence": (now - timedelta(minutes=window_minutes - 2)).isoformat(),
        "summary": f"Detected {template['count']} occurrences of '{pattern}' pattern in the last {window_minutes} minutes. Error rate increasing.",
    }
