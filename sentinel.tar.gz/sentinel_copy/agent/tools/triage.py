"""
triage_alert tool
Classifies an incoming alert: severity, service, environment, probable cause category.
In production this would query your CMDB, service catalogue, and alert history.
For the POC, it uses rule-based logic + simulated data.
"""
import re
from datetime import datetime

TRIAGE_TOOL_DEF = {
    "name": "triage_alert",
    "description": (
        "Triage an incoming alert. Returns severity (P1-P4), affected service name, "
        "environment, probable failure category, and on-call owner. "
        "Always call this first when a new alert arrives."
    ),
    "input_schema": {
        "type": "object",
        "properties": {
            "alert_name": {
                "type": "string",
                "description": "The name/title of the alert, e.g. 'HighMemoryUsage'"
            },
            "service": {
                "type": "string",
                "description": "Service or component name from the alert payload"
            },
            "environment": {
                "type": "string",
                "description": "Environment: prod, staging, dev"
            },
            "labels": {
                "type": "object",
                "description": "Key/value labels from the alert, e.g. {cluster: 'us-east-1'}"
            },
        },
        "required": ["alert_name", "service", "environment"],
    },
}

# Severity rules: pattern → (severity, category, suggested_runbook)
SEVERITY_RULES = [
    (r"OutOfMemory|OOMKill|oom",               "P1", "oom-kill",                "high-memory"),
    (r"CrashLoop|BackOff|crashloop",           "P1", "crash-loop",              "pod-crashloop"),
    (r"Down|Unreachable|Unavailable|down$",    "P1", "service-down",            "service-down"),
    (r"HighLatency|SlowResponse|latency",      "P2", "latency-degradation",     "high-latency"),
    (r"DiskFull|DiskPressure|disk",            "P2", "disk-pressure",           "disk-full"),
    (r"DBConnect|ConnectionPool|connection",   "P2", "db-connection-issue",     "db-connection-exhaustion"),
    (r"HighCPU|CPUThrottle|cpu",               "P2", "cpu-saturation",          "high-cpu"),
    (r"HighError|5xx|ErrorRate|error_rate",    "P2", "elevated-error-rate",     "high-error-rate"),
    (r"HighMemory|MemoryPressure|memory",      "P3", "memory-pressure",         "high-memory"),
    (r"Warning|Warn|warn",                     "P3", "warning",                 None),
    (r".*",                                    "P4", "informational",           None),
]

# Fake on-call rotation
ONCALL_OWNERS = {
    "api-gateway":     "platform-team",
    "auth-service":    "identity-team",
    "payment-service": "payments-team",
    "data-pipeline":   "data-team",
    "postgres":        "dba-team",
    "redis":           "platform-team",
    "worker":          "backend-team",
}

def triage_alert(alert_name: str, service: str, environment: str, labels: dict = None) -> dict:
    labels = labels or {}

    # Determine severity
    severity = "P4"
    category = "informational"
    suggested_runbook = None
    for pattern, sev, cat, runbook in SEVERITY_RULES:
        if re.search(pattern, alert_name, re.IGNORECASE):
            severity = sev
            category = cat
            suggested_runbook = runbook
            break

    # Escalate non-prod alerts
    if environment != "prod" and severity in ("P1", "P2"):
        severity = "P3"

    owner = ONCALL_OWNERS.get(service.lower(), "platform-team")

    return {
        "incident_id_hint": f"INC-{int(datetime.utcnow().timestamp())}",
        "severity": severity,
        "service": service,
        "environment": environment,
        "failure_category": category,
        "suggested_runbook": suggested_runbook,
        "oncall_owner": owner,
        "triage_timestamp": datetime.utcnow().isoformat(),
        "labels": labels,
        "needs_postmortem": severity in ("P1", "P2"),
        "auto_page": severity == "P1",
    }
