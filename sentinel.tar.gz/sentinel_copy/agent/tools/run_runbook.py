"""
run_runbook tool
Executes pre-defined SRE runbook steps.
Production: would run kubectl, aws cli, psql commands via a secure executor.
POC: simulates runbook execution with realistic outputs.
"""
from datetime import datetime

RUN_RUNBOOK_TOOL_DEF = {
    "name": "run_runbook",
    "description": (
        "Execute a named SRE runbook for a service. Runbooks run safe diagnostic commands "
        "(kubectl describe, metrics queries, etc.) and return findings. "
        "Never executes destructive operations — those are flagged as 'requires_approval'."
    ),
    "input_schema": {
        "type": "object",
        "properties": {
            "runbook_name": {
                "type": "string",
                "description": "Runbook to run: high-memory, high-latency, disk-full, pod-crashloop, db-connection-exhaustion",
            },
            "service": {
                "type": "string",
                "description": "Service to run the runbook against",
            },
            "namespace": {
                "type": "string",
                "description": "Kubernetes namespace (default: production)",
                "default": "production",
            },
        },
        "required": ["runbook_name", "service"],
    },
}

RUNBOOKS = {
    "high-memory": {
        "description": "Diagnose high memory usage and OOM conditions",
        "steps": [
            {
                "name": "Check pod resource usage",
                "command": "kubectl top pods -n {namespace} -l app={service}",
                "output": (
                    "NAME                              CPU(cores)   MEMORY(bytes)\n"
                    "{service}-7d9f8c-xk2p9             820m         1847Mi\n"
                    "{service}-7d9f8c-mn4q1             203m         432Mi\n"
                    "{service}-7d9f8c-rs7w3             198m         428Mi\n"
                    "\n⚠️  Pod {service}-7d9f8c-xk2p9 memory: 1847Mi / limit 2000Mi (92%)"
                ),
            },
            {
                "name": "Check OOM events",
                "command": "kubectl get events -n {namespace} --field-selector reason=OOMKilling",
                "output": (
                    "LAST SEEN   TYPE      REASON      OBJECT                              MESSAGE\n"
                    "3m          Warning   OOMKilling  pod/{service}-7d9f8c-xk2p9         Memory limit reached: 2000Mi, killed process"
                ),
            },
            {
                "name": "Check JVM heap (if Java service)",
                "command": "kubectl exec {service}-7d9f8c-xk2p9 -- jstat -gc 1 5",
                "output": "Heap used: 1.79GB / 2.0GB (89.7%) — Old Gen: 98.2% full — GC overhead: 45%",
            },
        ],
        "findings": "Pod {service}-7d9f8c-xk2p9 is consuming 92% of its 2Gi memory limit. OOMKill event detected 3 minutes ago. Old generation heap is 98% full indicating a memory leak or undersized heap.",
        "recommended_actions": [
            "Restart affected pod: kubectl rollout restart deployment/{service} -n {namespace}",
            {"action": "Increase memory limit to 4Gi in deployment spec", "requires_approval": True},
            "Review recent code changes for memory leaks (check object retention in heap dump)",
            {"action": "Scale deployment to add replicas while investigating", "requires_approval": True},
        ],
    },
    "high-latency": {
        "description": "Diagnose elevated response times and downstream degradation",
        "steps": [
            {
                "name": "Check downstream service latency",
                "command": "curl -s prometheus:9090/api/v1/query?query=histogram_quantile(0.99,http_request_duration_seconds_bucket{service='{service}'})",
                "output": "P99 latency: 4.82s (SLA: 0.5s) — 9.6x over SLA",
            },
            {
                "name": "Check connection pool saturation",
                "command": "kubectl exec -it {service}-* -- curl localhost:8080/metrics | grep hikari",
                "output": (
                    "hikaricp_connections_active{pool='HikariPool-1'} 100\n"
                    "hikaricp_connections_idle{pool='HikariPool-1'} 0\n"
                    "hikaricp_connections_pending{pool='HikariPool-1'} 47\n"
                    "hikaricp_connections_max{pool='HikariPool-1'} 100\n"
                    "\n⚠️  Connection pool 100% saturated, 47 threads waiting"
                ),
            },
            {
                "name": "Check circuit breaker state",
                "command": "kubectl exec {service}-* -- curl localhost:8080/actuator/circuitbreakers",
                "output": "payment-client: OPEN (failure rate: 87.3%, last 60s)\ndb-client: HALF_OPEN\ncache-client: CLOSED",
            },
        ],
        "findings": "Latency spike caused by connection pool exhaustion (100/100 connections in use, 47 queued). Circuit breaker to payment-service is OPEN after 87% failure rate. Downstream payment-service is likely the root cause.",
        "recommended_actions": [
            "Increase DB connection pool size: spring.datasource.hikari.maximum-pool-size=200",
            "Check payment-service health: kubectl rollout status deployment/payment-service",
            {"action": "Enable load shedding / rate limiting on {service}", "requires_approval": True},
        ],
    },
    "disk-full": {
        "description": "Diagnose and resolve disk pressure",
        "steps": [
            {
                "name": "Check disk usage",
                "command": "kubectl exec {service}-* -- df -h",
                "output": (
                    "Filesystem      Size  Used Avail Use% Mounted on\n"
                    "/dev/sda1        50G   48G  2.0G  96% /\n"
                    "/dev/sdb1       200G   185G 15G   92% /data\n"
                    "tmpfs           16G   0.1G  16G    1% /tmp"
                ),
            },
            {
                "name": "Find largest files",
                "command": "kubectl exec {service}-* -- du -sh /data/* | sort -rh | head -10",
                "output": (
                    "67G  /data/logs\n"
                    "54G  /data/heap-dumps\n"
                    "38G  /data/app-cache\n"
                    "12G  /data/tmp"
                ),
            },
            {
                "name": "Check log rotation config",
                "command": "kubectl exec {service}-* -- cat /etc/logrotate.conf",
                "output": "rotate 52 — weekly — compress: no\n⚠️  Log rotation not compressing. 67G of uncompressed logs found.",
            },
        ],
        "findings": "Disk at 96% usage. 67GB of uncompressed logs in /data/logs (log rotation misconfigured — compression disabled). 54GB of heap dumps from previous OOM crashes not cleaned up.",
        "recommended_actions": [
            {"action": "Clear old heap dumps: rm -rf /data/heap-dumps/*.hprof (keep last 2)", "requires_approval": True},
            "Enable log compression in logrotate.conf: add 'compress' directive",
            {"action": "Expand /data volume from 200G to 500G via PVC resize", "requires_approval": True},
            "Add disk usage alert at 80% threshold",
        ],
    },
    "pod-crashloop": {
        "description": "Diagnose pod CrashLoopBackOff",
        "steps": [
            {
                "name": "Check pod status and restart count",
                "command": "kubectl get pods -n {namespace} -l app={service}",
                "output": (
                    "NAME                          READY   STATUS             RESTARTS   AGE\n"
                    "{service}-7d9f8c-xk2p9        0/1     CrashLoopBackOff   14         47m\n"
                    "{service}-7d9f8c-mn4q1        1/1     Running            0          3h\n"
                    "{service}-7d9f8c-rs7w3        1/1     Running            0          3h"
                ),
            },
            {
                "name": "Get last pod logs",
                "command": "kubectl logs {service}-7d9f8c-xk2p9 --previous --tail=30",
                "output": (
                    "ERROR: Failed to connect to postgres://postgres:5432/appdb\n"
                    "FATAL: database connection required at startup — exiting\n"
                    "exit code: 1"
                ),
            },
            {
                "name": "Check recent deployments",
                "command": "kubectl rollout history deployment/{service} -n {namespace}",
                "output": (
                    "REVISION  CHANGE-CAUSE\n"
                    "4         Deploy v2.4.1 — feat: new connection pooling\n"
                    "3         Deploy v2.4.0\n"
                    "2         Deploy v2.3.9"
                ),
            },
        ],
        "findings": "Pod {service}-7d9f8c-xk2p9 has crashed 14 times in 47 minutes. Last error: DB connection failed at startup. Correlates with v2.4.1 deployment (new connection pooling code). Other pods on v2.4.0 are healthy.",
        "recommended_actions": [
            {"action": "Rollback to v2.4.0: kubectl rollout undo deployment/{service} -n {namespace}", "requires_approval": True},
            "Verify DB connectivity from healthy pod: kubectl exec {service}-7d9f8c-mn4q1 -- nc -zv postgres 5432",
            "Review v2.4.1 connection pooling changes before re-deploying",
        ],
    },
    "db-connection-exhaustion": {
        "description": "Diagnose database connection pool exhaustion",
        "steps": [
            {
                "name": "Check active DB connections",
                "command": "psql -h postgres -U admin -c \"SELECT count(*), state FROM pg_stat_activity GROUP BY state;\"",
                "output": (
                    " count | state  \n"
                    "-------+--------\n"
                    "   98  | active \n"
                    "    2  | idle   \n"
                    " (max_connections = 100)\n"
                    "⚠️  98/100 connections in use"
                ),
            },
            {
                "name": "Find long-running queries",
                "command": "psql -h postgres -U admin -c \"SELECT pid, now()-query_start AS duration, query FROM pg_stat_activity WHERE state='active' ORDER BY duration DESC LIMIT 5;\"",
                "output": (
                    " pid   | duration | query\n"
                    "-------+----------+------\n"
                    " 14823 | 00:08:32 | SELECT * FROM orders JOIN line_items ON...(full table scan)\n"
                    " 14756 | 00:06:14 | UPDATE users SET last_seen=... WHERE id IN (SELECT...)\n"
                    " 14701 | 00:04:02 | SELECT COUNT(*) FROM events WHERE created_at > ..."
                ),
            },
        ],
        "findings": "DB at maximum connections (98/100). Three long-running queries identified: oldest running 8+ minutes. Full table scan on orders table is likely blocking. Missing index on orders.created_at.",
        "recommended_actions": [
            {"action": "Kill long-running query (pid 14823): SELECT pg_terminate_backend(14823)", "requires_approval": True},
            "Add index: CREATE INDEX CONCURRENTLY idx_orders_created_at ON orders(created_at)",
            "Increase max_connections to 200 in postgresql.conf (requires restart)",
            "Add PgBouncer connection pooler in front of Postgres",
        ],
    },
}


def run_runbook(runbook_name: str, service: str, namespace: str = "production") -> dict:
    runbook = RUNBOOKS.get(runbook_name)
    if not runbook:
        return {
            "error": f"Runbook '{runbook_name}' not found",
            "available_runbooks": list(RUNBOOKS.keys()),
        }

    def fmt(text):
        return text.replace("{service}", service).replace("{namespace}", namespace)

    executed_steps = []
    for step in runbook["steps"]:
        executed_steps.append({
            "name": step["name"],
            "command": fmt(step["command"]),
            "output": fmt(step["output"]),
            "status": "completed",
            "executed_at": datetime.utcnow().isoformat(),
        })

    actions = []
    for action in runbook["recommended_actions"]:
        if isinstance(action, dict):
            actions.append({
                "action": fmt(action["action"]),
                "requires_approval": True,
                "warning": "⚠️ This action modifies production — requires human approval before executing",
            })
        else:
            actions.append({"action": fmt(action), "requires_approval": False})

    return {
        "runbook": runbook_name,
        "service": service,
        "namespace": namespace,
        "description": runbook["description"],
        "steps_executed": executed_steps,
        "findings": fmt(runbook["findings"]),
        "recommended_actions": actions,
        "runbook_completed_at": datetime.utcnow().isoformat(),
    }
