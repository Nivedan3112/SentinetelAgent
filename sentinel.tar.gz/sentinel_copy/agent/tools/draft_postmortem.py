"""
draft_postmortem tool
Generates a structured postmortem document skeleton.
Production: would create a Confluence/Notion page via API.
POC: returns formatted markdown.
"""
from datetime import datetime, timedelta
import random

DRAFT_POSTMORTEM_TOOL_DEF = {
    "name": "draft_postmortem",
    "description": (
        "Draft a postmortem document skeleton for a P1 or P2 incident. "
        "Creates a structured document with timeline, impact, root cause section, and action items. "
        "Only call for severity P1 or P2 incidents."
    ),
    "input_schema": {
        "type": "object",
        "properties": {
            "incident_id": {"type": "string"},
            "service": {"type": "string"},
            "severity": {"type": "string", "enum": ["P1", "P2"]},
            "failure_category": {"type": "string"},
            "detected_at": {"type": "string", "description": "ISO timestamp when alert fired"},
            "affected_users_estimate": {"type": "integer", "description": "Estimated number of affected users"},
        },
        "required": ["incident_id", "service", "severity", "failure_category"],
    },
}

def draft_postmortem(
    incident_id: str,
    service: str,
    severity: str,
    failure_category: str,
    detected_at: str = None,
    affected_users_estimate: int = None,
) -> dict:
    now = datetime.utcnow()
    detected = datetime.fromisoformat(detected_at) if detected_at else now - timedelta(minutes=15)
    users = affected_users_estimate or random.randint(500, 50000)

    doc = f"""# Postmortem: {incident_id} — {service} {failure_category.replace('-', ' ').title()}

**Severity:** {severity}
**Status:** In Progress (Draft)
**Date:** {now.strftime('%Y-%m-%d')}
**Author:** Sentinel AI (draft — requires human review)

---

## Summary
<!-- TODO: 2–3 sentence summary of what happened, impact, and resolution -->
[FILL IN: Brief description of incident for non-technical stakeholders]

---

## Timeline (UTC)

| Time | Event |
|------|-------|
| {detected.strftime('%H:%M')} | Alert fired: {failure_category} on {service} |
| {(detected + timedelta(minutes=2)).strftime('%H:%M')} | Sentinel agent triage initiated |
| {(detected + timedelta(minutes=5)).strftime('%H:%M')} | Root cause identified: [FILL IN] |
| {(detected + timedelta(minutes=8)).strftime('%H:%M')} | Incident response team notified |
| **TODO** | Mitigation action applied |
| **TODO** | Service restored to healthy state |
| **TODO** | Incident closed |

---

## Impact

- **Affected service:** {service}
- **Severity:** {severity}
- **Estimated affected users:** ~{users:,}
- **Duration:** [FILL IN once resolved]
- **Customer-facing impact:** [FILL IN: What did users experience?]
- **SLA breach:** [YES/NO — check SLA thresholds]

---

## Root Cause

<!-- TODO: Describe the technical root cause in detail -->

**Immediate cause:**
[FILL IN: What directly caused the failure?]

**Contributing factors:**
- [FILL IN]
- [FILL IN]

**Why it wasn't caught earlier:**
[FILL IN: Gap in monitoring, testing, or process]

---

## Detection

- **How detected:** Automated alert via Sentinel
- **Time to detect:** ~{(now - detected).seconds // 60} minutes from incident start
- **Could detection be faster?** [FILL IN]

---

## Resolution

**Steps taken:**
1. [FILL IN]
2. [FILL IN]

**Why this resolved it:**
[FILL IN]

---

## Action Items

| Priority | Action | Owner | Due Date |
|----------|--------|-------|----------|
| P1 | [FILL IN: Immediate fix] | [team] | {(now + timedelta(days=1)).strftime('%Y-%m-%d')} |
| P2 | [FILL IN: Prevent recurrence] | [team] | {(now + timedelta(days=7)).strftime('%Y-%m-%d')} |
| P3 | Improve detection/alerting | SRE | {(now + timedelta(days=14)).strftime('%Y-%m-%d')} |
| P3 | Add this scenario to runbook | SRE | {(now + timedelta(days=14)).strftime('%Y-%m-%d')} |

---

## Lessons Learned

- [FILL IN]
- [FILL IN]

---
*This postmortem was auto-drafted by Sentinel. All [FILL IN] sections require human input.*
*Review and complete within 48 hours of incident resolution.*
"""

    return {
        "incident_id": incident_id,
        "document_title": f"Postmortem {incident_id} — {service}",
        "confluence_url": f"https://confluence.example.com/display/SRE/postmortem-{incident_id.lower()}",
        "status": "draft",
        "created_at": now.isoformat(),
        "requires_human_completion": True,
        "markdown_content": doc,
        "word_count": len(doc.split()),
    }
