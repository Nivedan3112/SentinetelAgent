"""
notify_slack tool
Posts incident notifications to Slack.
Production: uses Slack WebAPI (slack_sdk).
POC: stores notifications in memory for the web UI to display.
"""
from datetime import datetime
from typing import Optional

NOTIFY_TOOL_DEF = {
    "name": "notify_slack",
    "description": (
        "Post a formatted incident notification to the Slack #incidents channel. "
        "Always call this as the final step of incident investigation with your complete findings."
    ),
    "input_schema": {
        "type": "object",
        "properties": {
            "severity": {
                "type": "string",
                "enum": ["P1", "P2", "P3", "P4"],
                "description": "Incident severity level",
            },
            "service": {"type": "string"},
            "title": {"type": "string", "description": "Short incident title"},
            "root_cause": {"type": "string", "description": "1-2 sentence root cause hypothesis"},
            "evidence": {
                "type": "array",
                "items": {"type": "string"},
                "description": "List of evidence bullet points (metrics, log findings)",
            },
            "actions": {
                "type": "array",
                "items": {"type": "string"},
                "description": "Recommended remediation actions",
            },
            "blast_radius": {"type": "string", "description": "Who/what is affected"},
            "eta_resolution": {"type": "string", "description": "Estimated time to resolution"},
        },
        "required": ["severity", "service", "title", "root_cause", "actions"],
    },
}

# In-memory store so the web UI can display notifications
_notification_store = []

SEVERITY_EMOJI = {"P1": "🔴", "P2": "🟠", "P3": "🟡", "P4": "🟢"}

def notify_slack(
    severity: str,
    service: str,
    title: str,
    root_cause: str,
    actions: list,
    evidence: list = None,
    blast_radius: str = None,
    eta_resolution: str = None,
) -> dict:
    emoji = SEVERITY_EMOJI.get(severity, "⚪")
    now = datetime.utcnow()

    evidence_text = "\n".join(f"• {e}" for e in (evidence or []))
    actions_text = "\n".join(f"{i+1}. {a}" for i, a in enumerate(actions))

    slack_message = f"""{emoji} *[{severity}] {service} — {title}*
> 📍 Environment: prod
> ⏱ Detected: {now.strftime('%H:%M UTC')}
> 👥 Blast radius: {blast_radius or 'Under investigation'}

*Root cause hypothesis:*
{root_cause}

*Evidence:*
{evidence_text or '• Under investigation'}

*Recommended actions:*
{actions_text}

*ETA to resolution:* {eta_resolution or 'TBD'}

_Posted by Sentinel SRE Agent · <https://github.com/yourorg/sentinel|View on GitHub>_"""

    notification = {
        "id": f"notif-{int(now.timestamp())}",
        "timestamp": now.isoformat(),
        "channel": "#incidents",
        "severity": severity,
        "service": service,
        "title": title,
        "message": slack_message,
        "root_cause": root_cause,
        "evidence": evidence or [],
        "actions": actions,
        "blast_radius": blast_radius,
        "eta_resolution": eta_resolution,
        "status": "sent",
    }

    _notification_store.append(notification)

    return {
        "status": "sent",
        "channel": "#incidents",
        "timestamp": now.isoformat(),
        "message_preview": slack_message[:200] + "...",
        "notification_id": notification["id"],
    }


def get_notifications() -> list:
    """Return all stored notifications (used by web UI)."""
    return list(reversed(_notification_store))
