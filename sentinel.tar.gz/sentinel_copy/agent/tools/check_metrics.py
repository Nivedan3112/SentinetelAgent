"""
check_metrics tool
Queries Prometheus for key metrics. 
In production: uses requests to hit your Prometheus/Thanos/Mimir HTTP API.
For POC: generates realistic synthetic timeseries with anomalies injected.
"""
import math
import random
import time
from datetime import datetime, timedelta

CHECK_METRICS_TOOL_DEF = {
    "name": "check_metrics",
    "description": (
        "Query Prometheus metrics for a service over a time window. "
        "Returns timeseries data for CPU, memory, error rate, request rate, and latency p99. "
        "Use this to confirm anomalies and understand the blast radius."
    ),
    "input_schema": {
        "type": "object",
        "properties": {
            "service": {
                "type": "string",
                "description": "Service name to query metrics for"
            },
            "window_minutes": {
                "type": "integer",
                "description": "How many minutes of history to fetch (default 30)",
                "default": 30,
            },
            "metrics": {
                "type": "array",
                "items": {"type": "string"},
                "description": "Which metrics to fetch: cpu_percent, memory_mb, error_rate, req_per_sec, latency_p99_ms",
            },
        },
        "required": ["service"],
    },
}


def _generate_timeseries(metric: str, window_minutes: int, anomaly: bool = False) -> list:
    """Generate a realistic-looking timeseries with optional spike/anomaly."""
    now = int(time.time())
    step = 60  # 1-minute resolution
    points = []

    baselines = {
        "cpu_percent":    (35, 8),
        "memory_mb":      (512, 40),
        "error_rate":     (0.2, 0.1),
        "req_per_sec":    (420, 60),
        "latency_p99_ms": (85, 15),
    }

    base, jitter = baselines.get(metric, (50, 10))

    for i in range(window_minutes):
        ts = now - (window_minutes - i) * step
        # Sinusoidal base + noise
        value = base + math.sin(i * 0.3) * (jitter * 0.5) + random.gauss(0, jitter * 0.3)

        # Inject anomaly in last 8 minutes
        if anomaly and i >= window_minutes - 8:
            spike_multipliers = {
                "cpu_percent":    3.5,
                "memory_mb":      2.8,
                "error_rate":     25,
                "req_per_sec":    0.1,   # drop
                "latency_p99_ms": 8,
            }
            value *= spike_multipliers.get(metric, 2)

        points.append({
            "timestamp": datetime.utcfromtimestamp(ts).isoformat(),
            "value": round(max(0, value), 2),
        })

    return points


def check_metrics(service: str, window_minutes: int = 30, metrics: list = None) -> dict:
    if metrics is None:
        metrics = ["cpu_percent", "memory_mb", "error_rate", "req_per_sec", "latency_p99_ms"]

    # Decide if this service is "sick" based on name hints
    anomaly = any(kw in service.lower() for kw in ["api", "payment", "auth", "gateway"])

    result = {
        "service": service,
        "window_minutes": window_minutes,
        "prometheus_endpoint": "http://prometheus:9090 (simulated)",
        "query_time": datetime.utcnow().isoformat(),
        "metrics": {},
    }

    for metric in metrics:
        series = _generate_timeseries(metric, window_minutes, anomaly=anomaly)
        values = [p["value"] for p in series]
        recent = values[-5:]   # last 5 minutes

        result["metrics"][metric] = {
            "timeseries": series[-10:],   # return last 10 points
            "current": round(recent[-1], 2),
            "avg_last_5m": round(sum(recent) / len(recent), 2),
            "max_last_30m": round(max(values), 2),
            "min_last_30m": round(min(values), 2),
            "trend": "spike" if recent[-1] > sum(values[:-5]) / max(len(values[:-5]), 1) * 1.8 else "stable",
            "anomaly_detected": anomaly and metric in ("error_rate", "latency_p99_ms", "cpu_percent"),
        }

    # Add summary
    anomalies = [m for m, d in result["metrics"].items() if d.get("anomaly_detected")]
    result["summary"] = {
        "anomalous_metrics": anomalies,
        "health_status": "degraded" if anomalies else "healthy",
        "recommendation": f"Investigate {', '.join(anomalies)}" if anomalies else "Metrics within normal range",
    }

    return result
